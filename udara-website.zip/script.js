function showMessage() {
    alert("Udara segar membuat hidup lebih baik! 🌬️");
}
