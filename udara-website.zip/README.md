# 🌤️ Udara Website

Project website sederhana bertema udara/langit.

## Fitur
- Desain sederhana dan modern
- Tema langit (gradient biru)
- Interaksi tombol JavaScript

## Cara Menjalankan
Buka file `index.html` di browser.

## Cara Upload ke GitHub
1. Extract zip
2. Buat repository baru di GitHub
3. Upload semua file
4. Commit 🚀
